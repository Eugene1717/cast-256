#include <iostream>
#include <iomanip>
#include <cstdint>
#include <vector>

void roundFunction(uint32_t& left, uint32_t& right, uint32_t subkey, bool decrypt=false) {
    uint32_t f = (right ^ ((right << 2) & (right >> 7)) ^ ((right << 10) & (right >> 17)) ^ ((right << 18) & (right >> 3)) ^ ((right << 24) & (right >> 5))) + subkey;

    if (decrypt) {
        left ^= f;
    } else {
        left ^= f;
    }
}

void encryptBlock(uint32_t& left, uint32_t& right, const std::vector<uint32_t>& subkeys, bool decrypt=false) {
    int numRounds = 16; // Количество раундов

    if (decrypt) {
        for (int i = numRounds - 1; i >= 0; --i) {
            roundFunction(left, right, subkeys[i], true);
            std::swap(left, right);
        }
    } else {
        for (int i = 0; i < numRounds; ++i) {
            roundFunction(left, right, subkeys[i]);
            std::swap(left, right);
        }
    }
    std::swap(left, right);
}

int main() {
    std::vector<uint32_t> subkeys; // Подключи для раундовых операций

    // Инициализация подключей (можно реализовать алгоритм инициализации ключей)
    // ...

    // Пример данных для шифрования
    uint32_t data[] = {0x01234567, 0x89ABCDEF};
    uint32_t originalData[2];
    std::copy(std::begin(data), std::end(data), std::begin(originalData));

    // Шифрование
    encryptBlock(data[0], data[1], subkeys);
    std::cout << "Зашифрованные данные: " << std::hex << data[0] << " " << data[1] << std::endl;

    // Дешифрование
    encryptBlock(data[0], data[1], subkeys, true);
    std::cout << "Дешифрованные данные: " << std::hex << data[0] << " " << data[1] << std::endl;

    if (data[0] == originalData[0] && data[1] == originalData[1]) {
        std::cout << "Успешно дешифровано!" << std::endl;
    } else {
        std::cout << "Ошибка при дешифровании!" << std::endl;
    }

    return 0;
}
